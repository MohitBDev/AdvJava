package com.app.service;

import com.app.pojos.Address;

public interface AddressService {
//add a method to get address details by id
	Address getAddressDetails(long adrId);
}
