package com.app.service;

import java.util.List;

import com.app.pojos.Department;

public interface DepartmentService {
	List<Department> getAllDepts();
}
