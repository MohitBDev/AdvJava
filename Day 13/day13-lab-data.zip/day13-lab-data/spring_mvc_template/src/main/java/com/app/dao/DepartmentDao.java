package com.app.dao;

import java.util.List;

import com.app.pojos.Department;

public interface DepartmentDao {
//add a method to get all depts
	List<Department> getAllDepartments();
}
