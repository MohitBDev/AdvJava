package com.app.controller;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.app.dto.AuthRequestDTO;
import com.app.dto.AuthRespDTO;
import com.app.dto.UserDTO;
import com.app.filters.JWTRequestFilter;
import com.app.jwt_utils.JwtUtils;
import com.app.service.UserService;

@RestController
@RequestMapping("/users")
public class UserController {
//dep : service layer i/f
	@Autowired
	private UserService userService;

	@Autowired
	private AuthenticationManager authMgr;
	
	@Autowired
	private JwtUtils jwtUtils;

	// http://host:port/users/signup , method=POST
	@PostMapping("/signup")
	public ResponseEntity<?> signupUser(@RequestBody @Valid UserDTO dto) {
		System.out.println("in signup user " + dto);

		return ResponseEntity.status(HttpStatus.CREATED).body(userService.registerNewUser(dto));
	}

	// http://host:port/users/signin , method=POST
	@PostMapping("/signin")
	public ResponseEntity<?> signinUser(@RequestBody @Valid AuthRequestDTO dto) {
		System.out.println("in signin user " + dto);
		// create authentication object to hold the credentials
		UsernamePasswordAuthenticationToken authentication = new UsernamePasswordAuthenticationToken(dto.getEmail(),
				dto.getPassword());
		//invoke auth mgr's method
		Authentication principal  =authMgr.authenticate(authentication);
		System.out.println("successful auth "+principal+" cls "+principal.getClass());
		//create JWT
		String jwtToken = jwtUtils.generateJwtToken(principal);
		return ResponseEntity.ok(new AuthRespDTO(jwtToken));
	}
}
